#### CARA INSTALL SCRIPT:
 download aplikasi termux android di [sini!](https://f-droid.org/repo/com.termux_118.apk), lalu buka aplikasinya ketikan perintah dibawah ini.
 ```
 $ pkg update && pkg upgrade
 $ pkg install python git
 $ pip install requests
 $ pip install bs4
 $ pip install rich
 $ git clone https://github.com/RENVVV/Simple
 ```
 oke sekarang script sudah terinstall
#### CARA MENJALANKAN SCRIPT:
 sekarang karena script sudah diinstall tinggal kita jalankan, ketikan perintah dibawah ini:
 ```
  $ cd Simple
  $ git pull
  $ python Simple.py
 ```
#### CONTOH HASIL CRACK FB:
![IMG_20220804_091721_676](https://user-images.githubusercontent.com/89802496/182751964-19679f1c-49d2-4e76-8a94-a9debda9183d.jpg)
